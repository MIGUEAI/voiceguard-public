# VoiceGuard

Plataforma de autenticação e gestão segura de ficheiros com suporte a 2FA, JWT, PostgreSQL e Flask.

## Como correr localmente

```bash
cd ~/voiceguard
source venv/bin/activate
python3 app.py

